package com.example.notification_page

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
